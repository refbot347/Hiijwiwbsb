const global = {
    superAdmin: [6940815173, ],
    usernameOwner: "@",
    botName: "CIKIW 1.0",
    botToken: "7727117270:AAHn4t3K6LlAqyfDfhIGZpEeFJ8JH3p662A",
    channelLink: "t.me/DEXSTAREFTAME",
    preview: 'https://b.top4top.io/m_3278si9yj1.mp4'
}

module.exports = global;